export type SymptomType = 'cough' | 'shortness_of_breath' | 'chest_pain' | 'fatigue' | 'weight_loss' | 'other';
export type TreatmentType = 'medication' | 'appointment' | 'therapy';
export type UserRole = 'patient' | 'caregiver';

export interface VitalSign {
  id?: string;
  uid: string;
  type: 'spo2' | 'weight' | 'heart_rate';
  value: number;
  unit: string;
  timestamp: any;
}

export interface CaregiverInvitation {
  id?: string;
  patientUid: string;
  caregiverEmail: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAt: any;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  role: UserRole;
  diagnosisDate?: string;
  stage?: string;
  oncologistName?: string;
  clinicPhone?: string;
  emergencyInstructions?: string;
}

export interface SymptomLog {
  id?: string;
  uid: string;
  type: SymptomType;
  severity: number; // 1-10
  timestamp: any; // Firestore Timestamp
  notes?: string;
}

export interface Treatment {
  id?: string;
  uid: string;
  title: string;
  type: TreatmentType;
  date: any; // Firestore Timestamp
  completed: boolean;
  notes?: string;
}

export interface MedicalDocument {
  id?: string;
  uid: string;
  title: string;
  type: 'scan' | 'xray' | 'lab_report' | 'prescription' | 'other';
  date: string; // YYYY-MM-DD
  fileUrl?: string;
  notes?: string;
  timestamp: any;
}
