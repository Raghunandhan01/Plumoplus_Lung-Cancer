import React, { useState } from 'react';
import { db, auth } from '../firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { UserProfile, UserRole } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner';
import { User, Shield, Bell, Moon, Sun, Save, Loader2 } from 'lucide-react';

interface SettingsProps {
  profile: UserProfile | null;
  onUpdate: (profile: UserProfile) => void;
}

export default function Settings({ profile, onUpdate }: SettingsProps) {
  const [loading, setLoading] = useState(false);
  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [role, setRole] = useState<UserRole>(profile?.role || 'patient');
  const [diagnosisDate, setDiagnosisDate] = useState(profile?.diagnosisDate || '');
  const [stage, setStage] = useState(profile?.stage || '');
  const [oncologistName, setOncologistName] = useState(profile?.oncologistName || '');
  const [clinicPhone, setClinicPhone] = useState(profile?.clinicPhone || '');
  const [emergencyInstructions, setEmergencyInstructions] = useState(profile?.emergencyInstructions || '');
  const [darkMode, setDarkMode] = useState(document.documentElement.classList.contains('dark'));

  const toggleDarkMode = () => {
    const isDark = document.documentElement.classList.toggle('dark');
    setDarkMode(isDark);
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
  };

  const handleSave = async () => {
    if (!auth.currentUser || !profile) return;
    setLoading(true);

    try {
      const updatedProfile: UserProfile = {
        ...profile,
        displayName,
        role,
        diagnosisDate,
        stage,
        oncologistName,
        clinicPhone,
        emergencyInstructions,
      };

      await updateDoc(doc(db, 'users', auth.currentUser.uid), {
        displayName,
        role,
        diagnosisDate,
        stage,
        oncologistName,
        clinicPhone,
        emergencyInstructions,
      });

      onUpdate(updatedProfile);
      toast.success("Profile updated successfully");
    } catch (error) {
      console.error("Error updating profile:", error);
      toast.error("Failed to update profile");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <User className="mr-2 h-5 w-5 text-blue-600" />
            Personal Information
          </CardTitle>
          <CardDescription>Update your profile details and role.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="name">Display Name</Label>
              <Input 
                id="name" 
                value={displayName} 
                onChange={(e) => setDisplayName(e.target.value)} 
                placeholder="Your name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="role">Your Role</Label>
              <Select value={role} onValueChange={(v: UserRole) => setRole(v)}>
                <SelectTrigger id="role">
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="patient">Patient</SelectItem>
                  <SelectItem value="caregiver">Caregiver</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label>Email Address</Label>
            <Input value={profile?.email} disabled className="bg-slate-50" />
            <p className="text-[10px] text-slate-400">Email cannot be changed as it is linked to your Google account.</p>
          </div>
        </CardContent>
      </Card>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Shield className="mr-2 h-5 w-5 text-purple-600" />
            Medical Context & Emergency
          </CardTitle>
          <CardDescription>This information helps personalize your experience and provides quick access in emergencies.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="diag-date">Diagnosis Date</Label>
              <Input 
                id="diag-date" 
                type="date" 
                value={diagnosisDate} 
                onChange={(e) => setDiagnosisDate(e.target.value)} 
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="stage">Cancer Stage</Label>
              <Select value={stage} onValueChange={setStage}>
                <SelectTrigger id="stage">
                  <SelectValue placeholder="Select stage" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="stage_1">Stage I</SelectItem>
                  <SelectItem value="stage_2">Stage II</SelectItem>
                  <SelectItem value="stage_3">Stage III</SelectItem>
                  <SelectItem value="stage_4">Stage IV</SelectItem>
                  <SelectItem value="unknown">Not Sure / Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="oncologist">Oncologist Name</Label>
              <Input 
                id="oncologist" 
                value={oncologistName} 
                onChange={(e) => setOncologistName(e.target.value)} 
                placeholder="Dr. Smith"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Clinic Phone</Label>
              <Input 
                id="phone" 
                value={clinicPhone} 
                onChange={(e) => setClinicPhone(e.target.value)} 
                placeholder="+1 (555) 000-0000"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="instructions">Emergency Instructions</Label>
            <Input 
              id="instructions" 
              value={emergencyInstructions} 
              onChange={(e) => setEmergencyInstructions(e.target.value)} 
              placeholder="e.g. Call clinic immediately if fever > 100.4F"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Bell className="mr-2 h-5 w-5 text-amber-500" />
            Preferences
          </CardTitle>
          <CardDescription>Customize how PlumoPlus looks and feels.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-3 rounded-lg border border-slate-100 dark:border-slate-800">
            <div className="flex items-center space-x-3">
              {darkMode ? <Moon className="h-5 w-5 text-blue-400" /> : <Sun className="h-5 w-5 text-amber-500" />}
              <div>
                <p className="text-sm font-medium">Dark Mode</p>
                <p className="text-xs text-slate-500">Easier on the eyes during treatment.</p>
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={toggleDarkMode}>
              {darkMode ? 'Switch to Light' : 'Switch to Dark'}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end pt-4">
        <Button 
          onClick={handleSave} 
          disabled={loading} 
          className="bg-blue-600 hover:bg-blue-700 min-w-[120px]"
        >
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
          Save Changes
        </Button>
      </div>
    </div>
  );
}
