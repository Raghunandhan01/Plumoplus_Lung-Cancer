/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { auth, signInWithGoogle, logout, db } from './firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc, getDocFromServer } from 'firebase/firestore';
import { UserProfile } from './types';
import { Button } from './components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Layout, LogOut, User as UserIcon, Activity, Calendar, MessageSquare, BookOpen, Loader2, Settings as SettingsIcon, Heart, FileText, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';

// Components
import Dashboard from './components/Dashboard';
import SymptomTracker from './components/SymptomTracker';
import TreatmentPlan from './components/TreatmentPlan';
import AIAssistant from './components/AIAssistant';
import ResourceLibrary from './components/ResourceLibrary';
import Settings from './components/Settings';
import VitalsTracker from './components/VitalsTracker';
import ReportGenerator from './components/ReportGenerator';
import CaregiverSystem from './components/CaregiverSystem';
import MedicalDocuments from './components/MedicalDocuments';
import LandingPage from './components/LandingPage';
import { Toaster } from './components/ui/sonner';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    // Initialize theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Test connection
        try {
          await getDocFromServer(doc(db, 'test', 'connection'));
        } catch (error) {
          if (error instanceof Error && error.message.includes('the client is offline')) {
            console.error("Firebase connection error. Check configuration.");
          }
        }

        // Fetch or create profile
        const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
        if (userDoc.exists()) {
          setProfile(userDoc.data() as UserProfile);
        } else {
          const newProfile: UserProfile = {
            uid: currentUser.uid,
            displayName: currentUser.displayName || 'User',
            email: currentUser.email || '',
            role: 'patient',
          };
          await setDoc(doc(db, 'users', currentUser.uid), newProfile);
          setProfile(newProfile);
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-50">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!user) {
    return <LandingPage />;
  }

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-300">
      {/* Sidebar */}
      <aside className="fixed bottom-0 left-0 z-50 w-full border-t bg-white dark:bg-slate-900 p-2 md:static md:h-screen md:w-64 md:border-r md:border-slate-200 dark:border-slate-800 md:border-t-0">
        <div className="hidden h-16 items-center px-6 md:flex">
          <Activity className="mr-2 h-6 w-6 text-primary" />
          <span className="text-xl font-bold tracking-tight font-heading">PlumoPlus</span>
        </div>

        <nav className="flex justify-around space-y-1 px-2 md:block md:px-4">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: Layout },
            { id: 'symptoms', label: 'Symptoms', icon: Activity },
            { id: 'treatments', label: 'Treatments', icon: Calendar },
            { id: 'vitals', label: 'Vitals', icon: Activity },
            { id: 'documents', label: 'Medical Docs', icon: FileText },
            { id: 'reports', label: 'Reports', icon: FileText },
            { id: 'caregivers', label: 'Caregivers', icon: Users },
            { id: 'assistant', label: 'AI Assistant', icon: MessageSquare },
            { id: 'resources', label: 'Resources', icon: BookOpen },
            { id: 'settings', label: 'Settings', icon: SettingsIcon },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "flex flex-col items-center rounded-lg px-3 py-2 text-xs font-medium transition-colors md:w-full md:flex-row md:text-sm",
                activeTab === item.id 
                  ? "bg-primary/10 text-primary" 
                  : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
              )}
            >
              <item.icon className={cn("h-5 w-5 md:mr-3", activeTab === item.id ? "text-primary" : "text-muted-foreground/60")} />
              <span className="mt-1 md:mt-0">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="absolute bottom-4 left-0 hidden w-full px-4 md:block">
          <div className="mb-4 flex items-center px-4 py-2">
            <div className="mr-3 h-8 w-8 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center">
              <UserIcon className="h-4 w-4 text-slate-500 dark:text-slate-400" />
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="truncate text-sm font-medium">{profile?.displayName}</p>
              <p className="truncate text-xs text-slate-500 dark:text-slate-400">{profile?.role}</p>
            </div>
          </div>
          <Button variant="ghost" onClick={logout} className="w-full justify-start text-slate-500 dark:text-slate-400 hover:text-red-600 dark:hover:text-red-400">
            <LogOut className="mr-3 h-4 w-4" />
            Sign Out
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 pb-20 md:pb-0">
        <header className="sticky top-0 z-40 flex h-16 items-center justify-between border-b bg-background/80 px-4 backdrop-blur-md md:px-8">
          <h2 className="text-lg font-semibold capitalize font-heading">{activeTab}</h2>
          <div className="flex items-center space-x-4">
            <div className="md:hidden">
               <Button variant="ghost" size="icon" onClick={logout}>
                 <LogOut className="h-5 w-5 text-slate-500 dark:text-slate-400" />
               </Button>
            </div>
          </div>
        </header>

        <div className="p-4 md:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'dashboard' && <Dashboard profile={profile} />}
              {activeTab === 'symptoms' && <SymptomTracker />}
              {activeTab === 'treatments' && <TreatmentPlan />}
              {activeTab === 'vitals' && <VitalsTracker />}
              {activeTab === 'reports' && <ReportGenerator />}
              {activeTab === 'caregivers' && <CaregiverSystem />}
              {activeTab === 'documents' && <MedicalDocuments />}
              {activeTab === 'assistant' && <AIAssistant />}
              {activeTab === 'resources' && <ResourceLibrary />}
              {activeTab === 'settings' && <Settings profile={profile} onUpdate={setProfile} />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
      <Toaster />
    </div>
  );
}
