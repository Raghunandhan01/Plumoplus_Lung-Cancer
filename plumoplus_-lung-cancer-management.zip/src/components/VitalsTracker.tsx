import React, { useState, useEffect } from 'react';
import { db, auth } from '../firebase';
import { collection, addDoc, query, where, orderBy, onSnapshot, Timestamp } from 'firebase/firestore';
import { VitalSign } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner';
import { Activity, Thermometer, Weight, Heart, Plus, History, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function VitalsTracker() {
  const [vitals, setVitals] = useState<VitalSign[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [type, setType] = useState<'spo2' | 'weight' | 'heart_rate'>('spo2');
  const [value, setValue] = useState('');

  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, 'vitals'),
      where('uid', '==', auth.currentUser.uid),
      orderBy('timestamp', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as VitalSign[];
      setVitals(data);
      setLoading(false);
    }, (error) => {
      console.error("Vitals listener error:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser || !value) return;

    try {
      const unit = type === 'spo2' ? '%' : type === 'weight' ? 'kg' : 'bpm';
      await addDoc(collection(db, 'vitals'), {
        uid: auth.currentUser.uid,
        type,
        value: parseFloat(value),
        unit,
        timestamp: Timestamp.now()
      });
      setIsAdding(false);
      setValue('');
      toast.success("Vital sign recorded");
    } catch (error) {
      console.error("Error adding vital:", error);
      toast.error("Failed to record vital sign");
    }
  };

  const getChartData = (vitalType: string) => {
    return vitals
      .filter(v => v.type === vitalType)
      .slice(0, 10)
      .reverse()
      .map(v => ({
        date: format(v.timestamp.toDate(), 'MMM d'),
        value: v.value
      }));
  };

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold">Vitals Tracker</h3>
        <Button onClick={() => setIsAdding(!isAdding)} variant={isAdding ? "ghost" : "default"}>
          {isAdding ? "Cancel" : <><Plus className="mr-2 h-4 w-4" /> Add Vital</>}
        </Button>
      </div>

      {isAdding && (
        <Card className="border-none shadow-sm">
          <CardContent className="pt-6">
            <form onSubmit={handleAdd} className="grid gap-4 md:grid-cols-3 items-end">
              <div className="space-y-2">
                <Label>Type</Label>
                <Select value={type} onValueChange={(v: any) => setType(v)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="spo2">Oxygen Saturation (SpO2)</SelectItem>
                    <SelectItem value="weight">Weight</SelectItem>
                    <SelectItem value="heart_rate">Heart Rate</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Value ({type === 'spo2' ? '%' : type === 'weight' ? 'kg' : 'bpm'})</Label>
                <Input 
                  type="number" 
                  step="0.1"
                  value={value} 
                  onChange={(e) => setValue(e.target.value)} 
                  placeholder="Enter value"
                  required
                />
              </div>
              <Button type="submit" className="bg-blue-600">Save Vital</Button>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-sm font-medium flex items-center">
              <Activity className="mr-2 h-4 w-4 text-blue-600" />
              SpO2 Trend (%)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={getChartData('spo2')}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="date" fontSize={10} />
                  <YAxis fontSize={10} domain={['dataMin - 2', 'dataMax + 2']} />
                  <Tooltip />
                  <Line type="monotone" dataKey="value" stroke="#2563eb" strokeWidth={2} dot={{ r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="text-sm font-medium flex items-center">
              <History className="mr-2 h-4 w-4 text-slate-400" />
              Recent Logs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {vitals.slice(0, 5).map((v) => (
                <div key={v.id} className="flex items-center justify-between p-3 rounded-lg bg-slate-50">
                  <div className="flex items-center space-x-3">
                    {v.type === 'spo2' && <Activity className="h-4 w-4 text-blue-600" />}
                    {v.type === 'weight' && <Weight className="h-4 w-4 text-emerald-600" />}
                    {v.type === 'heart_rate' && <Heart className="h-4 w-4 text-red-600" />}
                    <div>
                      <p className="text-sm font-medium capitalize">{v.type.replace('_', ' ')}</p>
                      <p className="text-xs text-slate-500">{format(v.timestamp.toDate(), 'MMM d, h:mm a')}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold">{v.value} {v.unit}</p>
                  </div>
                </div>
              ))}
              {vitals.length === 0 && (
                <p className="text-center text-sm text-slate-400 py-4">No vitals recorded yet.</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
