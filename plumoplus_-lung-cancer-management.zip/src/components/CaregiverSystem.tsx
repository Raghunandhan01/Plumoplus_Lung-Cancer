import React, { useState, useEffect } from 'react';
import { db, auth } from '../firebase';
import { collection, setDoc, query, where, onSnapshot, updateDoc, doc, deleteDoc, Timestamp } from 'firebase/firestore';
import { CaregiverInvitation, UserProfile } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { toast } from 'sonner';
import { Users, UserPlus, Mail, Check, X, Loader2, Shield, Heart } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../lib/utils';

export default function CaregiverSystem() {
  const [invitations, setInvitations] = useState<CaregiverInvitation[]>([]);
  const [receivedInvitations, setReceivedInvitations] = useState<CaregiverInvitation[]>([]);
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState('');
  const [isInviting, setIsInviting] = useState(false);

  useEffect(() => {
    if (!auth.currentUser || !auth.currentUser.email) return;

    // Invitations sent by me (as a patient)
    const sentQ = query(
      collection(db, 'invitations'),
      where('patientUid', '==', auth.currentUser.uid)
    );

    const unsubscribeSent = onSnapshot(sentQ, (snapshot) => {
      setInvitations(snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as CaregiverInvitation[]);
    }, (error) => {
      console.error("Sent invitations listener error:", error);
    });

    // Invitations received by me (as a caregiver)
    const receivedQ = query(
      collection(db, 'invitations'),
      where('caregiverEmail', '==', auth.currentUser.email.toLowerCase())
    );

    const unsubscribeReceived = onSnapshot(receivedQ, (snapshot) => {
      setReceivedInvitations(snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as CaregiverInvitation[]);
      setLoading(false);
    }, (error) => {
      console.error("Received invitations listener error:", error);
      setLoading(false);
    });

    return () => {
      unsubscribeSent();
      unsubscribeReceived();
    };
  }, []);

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser || !email) return;

    try {
      const caregiverEmail = email.toLowerCase();
      const invitationId = `${caregiverEmail}_${auth.currentUser.uid}`;
      await setDoc(doc(db, 'invitations', invitationId), {
        patientUid: auth.currentUser.uid,
        caregiverEmail,
        status: 'pending',
        createdAt: Timestamp.now()
      });
      setEmail('');
      setIsInviting(false);
      toast.success("Invitation sent to caregiver");
    } catch (error) {
      console.error("Error sending invitation:", error);
      toast.error("Failed to send invitation");
    }
  };

  const handleStatusUpdate = async (invitationId: string, status: 'accepted' | 'declined') => {
    try {
      await updateDoc(doc(db, 'invitations', invitationId), { status });
      toast.success(`Invitation ${status}`);
    } catch (error) {
      console.error("Error updating invitation:", error);
      toast.error("Action failed");
    }
  };

  const handleRemove = async (invitationId: string) => {
    try {
      await deleteDoc(doc(db, 'invitations', invitationId));
      toast.success("Caregiver removed");
    } catch (error) {
      console.error("Error removing caregiver:", error);
      toast.error("Failed to remove caregiver");
    }
  };

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold">Caregiver Network</h3>
        <Button onClick={() => setIsInviting(!isInviting)} variant={isInviting ? "ghost" : "default"}>
          {isInviting ? "Cancel" : <><UserPlus className="mr-2 h-4 w-4" /> Invite Caregiver</>}
        </Button>
      </div>

      {isInviting && (
        <Card className="border-none shadow-sm">
          <CardContent className="pt-6">
            <form onSubmit={handleInvite} className="flex gap-4 items-end">
              <div className="flex-1 space-y-2">
                <Label>Caregiver's Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <Input 
                    type="email" 
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} 
                    placeholder="caregiver@example.com"
                    className="pl-10"
                    required
                  />
                </div>
              </div>
              <Button type="submit" className="bg-blue-600">Send Invite</Button>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Received Invitations (For Caregivers) */}
      {receivedInvitations.length > 0 && (
        <div className="space-y-4">
          <h4 className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Pending Requests</h4>
          <div className="grid gap-4">
            {receivedInvitations.filter(i => i.status === 'pending').map(inv => (
              <Card key={inv.id} className="border-blue-100 bg-blue-50/30">
                <CardContent className="flex items-center justify-between p-4">
                  <div className="flex items-center space-x-3">
                    <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                      <Heart className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">Invitation to be a Caregiver</p>
                      <p className="text-xs text-slate-500">From Patient UID: {inv.patientUid.slice(0, 8)}...</p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button size="sm" onClick={() => handleStatusUpdate(inv.id!, 'accepted')} className="bg-emerald-600 hover:bg-emerald-700">
                      <Check className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleStatusUpdate(inv.id!, 'declined')} className="text-red-600 hover:bg-red-50">
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Sent Invitations (For Patients) */}
      <div className="space-y-4">
        <h4 className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Your Caregivers</h4>
        <div className="grid gap-4 md:grid-cols-2">
          {invitations.map(inv => (
            <Card key={inv.id} className="border-none shadow-sm">
              <CardContent className="flex items-center justify-between p-4">
                <div className="flex items-center space-x-3">
                  <div className={cn(
                    "h-10 w-10 rounded-full flex items-center justify-center",
                    inv.status === 'accepted' ? "bg-emerald-100" : "bg-slate-100"
                  )}>
                    <Users className={cn(
                      "h-5 w-5",
                      inv.status === 'accepted' ? "text-emerald-600" : "text-slate-400"
                    )} />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{inv.caregiverEmail}</p>
                    <div className="flex items-center space-x-2">
                      <span className={cn(
                        "text-[10px] px-1.5 py-0.5 rounded-full font-bold uppercase",
                        inv.status === 'accepted' ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"
                      )}>
                        {inv.status}
                      </span>
                      <span className="text-[10px] text-slate-400">Sent {format(inv.createdAt.toDate(), 'MMM d')}</span>
                    </div>
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={() => handleRemove(inv.id!)} className="text-slate-400 hover:text-red-600">
                  <X className="h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
          {invitations.length === 0 && (
            <div className="col-span-full py-12 text-center border-2 border-dashed rounded-xl border-slate-200">
              <Shield className="mx-auto h-12 w-12 text-slate-200 mb-2" />
              <p className="text-sm text-slate-400">No caregivers invited yet.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
