import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { BookOpen, ExternalLink, FileText, Video } from 'lucide-react';

const resources = [
  {
    title: "Understanding Lung Cancer Stages",
    type: "Article",
    category: "Education",
    description: "A comprehensive guide to what the different stages of lung cancer mean for your treatment.",
    icon: FileText,
  },
  {
    title: "Nutrition Tips During Chemotherapy",
    type: "Guide",
    category: "Wellness",
    description: "How to maintain your appetite and strength during treatment cycles.",
    icon: BookOpen,
  },
  {
    title: "Breathing Exercises for Lung Health",
    type: "Video",
    category: "Therapy",
    description: "Simple exercises you can do at home to improve lung capacity and reduce anxiety.",
    icon: Video,
  },
  {
    title: "Managing Fatigue and Energy",
    type: "Article",
    category: "Wellness",
    description: "Practical strategies for dealing with treatment-related exhaustion.",
    icon: FileText,
  }
];

export default function ResourceLibrary() {
  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        {resources.map((res, i) => (
          <Card key={i} className="border-none shadow-sm hover:shadow-md transition-shadow cursor-pointer group">
            <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-2">
              <div className="flex items-center space-x-3">
                <div className="rounded-lg bg-slate-100 p-2 text-slate-600 group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors">
                  <res.icon className="h-5 w-5" />
                </div>
                <div>
                  <CardTitle className="text-base">{res.title}</CardTitle>
                  <div className="flex space-x-2 mt-1">
                    <Badge variant="secondary" className="text-[10px] uppercase font-bold tracking-wider">{res.type}</Badge>
                    <Badge variant="outline" className="text-[10px] uppercase font-bold tracking-wider">{res.category}</Badge>
                  </div>
                </div>
              </div>
              <ExternalLink className="h-4 w-4 text-slate-300 group-hover:text-blue-600 transition-colors" />
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-500 leading-relaxed">
                {res.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-none bg-blue-600 text-white shadow-lg shadow-blue-200">
        <CardContent className="p-8 flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
          <div className="space-y-2 text-center md:text-left">
            <h3 className="text-xl font-bold">Need more specific information?</h3>
            <p className="text-blue-100 text-sm max-w-md">
              Our AI Assistant can help you find answers to specific questions about your diagnosis and treatment plan.
            </p>
          </div>
          <button className="rounded-full bg-white px-6 py-2 text-sm font-bold text-blue-600 hover:bg-blue-50 transition-colors">
            Ask Assistant
          </button>
        </CardContent>
      </Card>
    </div>
  );
}
