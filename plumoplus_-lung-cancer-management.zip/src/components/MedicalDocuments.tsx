import React, { useState, useEffect } from 'react';
import { MedicalDocument } from '../types';
import { db, auth } from '../firebase';
import { collection, query, where, onSnapshot, addDoc, deleteDoc, doc, Timestamp, orderBy } from 'firebase/firestore';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { FileText, Plus, Trash2, ExternalLink, FileSearch, Image as ImageIcon, Clipboard, FileType } from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';

export default function MedicalDocuments() {
  const [documents, setDocuments] = useState<MedicalDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  
  // Form state
  const [title, setTitle] = useState('');
  const [type, setType] = useState<'scan' | 'xray' | 'lab_report' | 'prescription' | 'other'>('scan');
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [fileUrl, setFileUrl] = useState('');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, 'medical_documents'),
      where('uid', '==', auth.currentUser.uid),
      orderBy('date', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as MedicalDocument[];
      setDocuments(docs);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching documents:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleAddDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser || !title || !date) return;

    try {
      await addDoc(collection(db, 'medical_documents'), {
        uid: auth.currentUser.uid,
        title,
        type,
        date,
        fileUrl,
        notes,
        timestamp: Timestamp.now()
      });
      
      setTitle('');
      setType('scan');
      setDate(format(new Date(), 'yyyy-MM-dd'));
      setFileUrl('');
      setNotes('');
      setIsAdding(false);
      toast.success("Document added successfully");
    } catch (error) {
      console.error("Error adding document:", error);
      toast.error("Failed to add document");
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'medical_documents', id));
      toast.success("Document deleted");
    } catch (error) {
      console.error("Error deleting document:", error);
      toast.error("Failed to delete document");
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'scan': return <FileSearch className="h-5 w-5 text-blue-500" />;
      case 'xray': return <ImageIcon className="h-5 w-5 text-purple-500" />;
      case 'lab_report': return <Clipboard className="h-5 w-5 text-emerald-500" />;
      case 'prescription': return <FileText className="h-5 w-5 text-amber-500" />;
      default: return <FileType className="h-5 w-5 text-slate-500" />;
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto p-4 md:p-0">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Medical Reports & Scans</h2>
          <p className="text-slate-500 text-sm">Keep all your important medical documents in one place.</p>
        </div>
        <Button onClick={() => setIsAdding(!isAdding)} className="bg-blue-600">
          {isAdding ? "Cancel" : <><Plus className="mr-2 h-4 w-4" /> Add Document</>}
        </Button>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <Card className="border-none shadow-md overflow-hidden">
              <CardHeader className="bg-slate-50 dark:bg-slate-800/50">
                <CardTitle className="text-lg">New Document Entry</CardTitle>
                <CardDescription>Provide details about your medical report or scan.</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <form onSubmit={handleAddDocument} className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="title">Document Title</Label>
                    <Input 
                      id="title" 
                      placeholder="e.g., Chest CT Scan - April 2024" 
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="type">Document Type</Label>
                    <Select value={type} onValueChange={(v: any) => setType(v)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="scan">CT / PET Scan</SelectItem>
                        <SelectItem value="xray">X-Ray</SelectItem>
                        <SelectItem value="lab_report">Lab Report / Blood Work</SelectItem>
                        <SelectItem value="prescription">Prescription</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="date">Report Date</Label>
                    <Input 
                      id="date" 
                      type="date" 
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="fileUrl">Document Link (Optional)</Label>
                    <Input 
                      id="fileUrl" 
                      placeholder="Link to Google Drive, Dropbox, etc." 
                      value={fileUrl}
                      onChange={(e) => setFileUrl(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="notes">Notes / Findings</Label>
                    <Input 
                      id="notes" 
                      placeholder="Summary of results or doctor's comments..." 
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                    />
                  </div>
                  <div className="md:col-span-2 flex justify-end pt-2">
                    <Button type="submit" className="bg-blue-600 w-full md:w-auto">Save Document</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {loading ? (
          <div className="col-span-full text-center py-12">
            <p className="text-slate-400">Loading documents...</p>
          </div>
        ) : documents.length === 0 ? (
          <div className="col-span-full text-center py-12 bg-slate-50 dark:bg-slate-900/30 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800">
            <FileText className="h-12 w-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium">No documents yet</h3>
            <p className="text-slate-500 text-sm">Upload your first scan or report to keep it safe.</p>
            <Button variant="outline" onClick={() => setIsAdding(true)} className="mt-4">
              Add Your First Document
            </Button>
          </div>
        ) : (
          documents.map((doc) => (
            <motion.div
              key={doc.id}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
            >
              <Card className="border-none shadow-sm hover:shadow-md transition-shadow group h-full flex flex-col">
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800">
                      {getIcon(doc.type)}
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => doc.id && handleDelete(doc.id)}
                      className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500 transition-opacity"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <CardTitle className="text-base mt-2 line-clamp-1">{doc.title}</CardTitle>
                  <CardDescription className="text-xs">
                    {format(new Date(doc.date), 'MMMM d, yyyy')}
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="inline-block px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                      {doc.type.replace('_', ' ')}
                    </div>
                    {doc.notes && (
                      <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-3 italic">
                        "{doc.notes}"
                      </p>
                    )}
                  </div>
                  
                  {doc.fileUrl && (
                    <div className="mt-4 pt-4 border-t border-slate-50 dark:border-slate-800">
                      <a 
                        href={doc.fileUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center text-xs font-bold text-blue-600 hover:text-blue-700 transition-colors"
                      >
                        <ExternalLink className="mr-2 h-3 w-3" />
                        View Document
                      </a>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
