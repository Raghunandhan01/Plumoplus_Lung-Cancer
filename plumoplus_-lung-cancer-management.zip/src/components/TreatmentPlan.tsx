import React, { useState, useEffect } from 'react';
import { db, auth } from '../firebase';
import { collection, addDoc, query, where, onSnapshot, orderBy, Timestamp, updateDoc, doc, deleteDoc } from 'firebase/firestore';
import { Treatment, TreatmentType } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Plus, Calendar, Trash2, CheckCircle2, Circle } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../lib/utils';
import { toast } from 'sonner';

export default function TreatmentPlan() {
  const [treatments, setTreatments] = useState<Treatment[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  
  // Form state
  const [title, setTitle] = useState('');
  const [type, setType] = useState<TreatmentType>('medication');
  const [date, setDate] = useState('');

  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, 'treatments'),
      where('uid', '==', auth.currentUser.uid),
      orderBy('date', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const newTreatments = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Treatment[];
      setTreatments(newTreatments);
    }, (error) => {
      console.error("Treatments listener error:", error);
    });

    return () => unsubscribe();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;

    try {
      await addDoc(collection(db, 'treatments'), {
        uid: auth.currentUser.uid,
        title,
        type,
        date: Timestamp.fromDate(new Date(date)),
        completed: false
      });
      setIsAdding(false);
      setTitle('');
      setDate('');
      toast.success("Item added to schedule");
    } catch (error) {
      console.error("Error adding treatment:", error);
      toast.error("Failed to add item");
    }
  };

  const toggleComplete = async (id: string, current: boolean) => {
    await updateDoc(doc(db, 'treatments', id), { completed: !current });
  };

  const deleteTreatment = async (id: string) => {
    await deleteDoc(doc(db, 'treatments', id));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Treatment Schedule</h3>
        <Button onClick={() => setIsAdding(!isAdding)} className="bg-blue-600">
          <Plus className="mr-2 h-4 w-4" />
          Add Item
        </Button>
      </div>

      {isAdding && (
        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle>Add Treatment or Appointment</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Title</Label>
                  <Input 
                    placeholder="e.g. Morning Medication, Oncology Appt" 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Type</Label>
                  <Select value={type} onValueChange={(v: TreatmentType) => setType(v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="medication">Medication</SelectItem>
                      <SelectItem value="appointment">Appointment</SelectItem>
                      <SelectItem value="therapy">Therapy</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Date & Time</Label>
                <Input 
                  type="datetime-local" 
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsAdding(false)}>Cancel</Button>
                <Button type="submit" className="bg-blue-600">Add to Schedule</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="space-y-4">
        {treatments.map((item) => (
          <Card key={item.id} className={cn(
            "border-none shadow-sm transition-opacity",
            item.completed && "opacity-60"
          )}>
            <CardContent className="flex items-center p-4">
              <button 
                onClick={() => item.id && toggleComplete(item.id, item.completed)}
                className="mr-4 text-blue-600"
              >
                {item.completed ? <CheckCircle2 className="h-6 w-6" /> : <Circle className="h-6 w-6" />}
              </button>
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <h4 className={cn("font-semibold", item.completed && "line-through")}>{item.title}</h4>
                  <span className={cn(
                    "rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider",
                    item.type === 'medication' ? "bg-green-50 text-green-600" :
                    item.type === 'appointment' ? "bg-purple-50 text-purple-600" :
                    "bg-blue-50 text-blue-600"
                  )}>
                    {item.type}
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  {format(item.date.toDate(), 'EEEE, MMM d, h:mm a')}
                </p>
              </div>
              <Button variant="ghost" size="icon" onClick={() => item.id && deleteTreatment(item.id)} className="text-slate-300 hover:text-red-600">
                <Trash2 className="h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        ))}
        {treatments.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-slate-400">
            <Calendar className="mb-2 h-12 w-12 opacity-20" />
            <p>Your schedule is clear. Add your first treatment or appointment.</p>
          </div>
        )}
      </div>
    </div>
  );
}
