import React from 'react';
import { Button } from './ui/button';
import { Activity, Shield, Users, MessageSquare, Heart, CheckCircle2, ArrowRight, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { signInWithGoogle } from '../firebase';

export default function LandingPage() {
  const features = [
    {
      icon: <Activity className="h-6 w-6 text-blue-500" />,
      title: "Symptom Tracking",
      description: "Log cough, fatigue, and SpO2 levels with clinical precision."
    },
    {
      icon: <MessageSquare className="h-6 w-6 text-purple-500" />,
      title: "AI Assistant",
      description: "Get instant explanations for medical terms and symptom management tips."
    },
    {
      icon: <Users className="h-6 w-6 text-emerald-500" />,
      title: "Caregiver Sync",
      description: "Securely share your health status with family and doctors in real-time."
    },
    {
      icon: <Shield className="h-6 w-6 text-amber-500" />,
      title: "Secure Vault",
      description: "Store your CT scans, X-rays, and lab reports in an encrypted cloud."
    }
  ];

  return (
    <div className="min-h-screen bg-background text-foreground font-sans">
      {/* Navigation */}
      <nav className="flex items-center justify-between px-6 py-4 max-w-7xl mx-auto">
        <div className="flex items-center space-x-2">
          <div className="bg-primary p-1.5 rounded-lg">
            <Activity className="h-5 w-5 text-white" />
          </div>
          <span className="text-xl font-bold tracking-tight font-heading">PlumoPlus</span>
        </div>
        <Button onClick={signInWithGoogle} variant="ghost" className="font-semibold">
          Sign In
        </Button>
      </nav>

      {/* Hero Section */}
      <section className="px-6 pt-20 pb-32 max-w-7xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-1.5 rounded-full text-sm font-bold mb-8">
            <Sparkles className="h-4 w-4" />
            <span>Advanced Lung Cancer Management</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 leading-[1.1] font-heading">
            Your Journey, <br />
            <span className="text-primary italic">Managed with Care.</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed">
            PlumoPlus is a comprehensive companion for lung cancer patients and caregivers. 
            Track symptoms, manage treatments, and get AI-powered guidance—all in one secure place.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button onClick={signInWithGoogle} size="lg" className="bg-primary hover:bg-primary/90 h-14 px-8 text-lg rounded-2xl shadow-lg shadow-primary/20">
              Get Started for Free <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <div className="flex items-center space-x-2 text-muted-foreground text-sm">
              <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              <span>HIPAA-Compliant Security</span>
            </div>
          </div>
        </motion.div>

        {/* Mockup Preview */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="mt-20 relative"
        >
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent z-10" />
          <div className="rounded-3xl border-8 border-foreground/5 overflow-hidden shadow-2xl max-w-4xl mx-auto bg-card">
            <img 
              src="https://picsum.photos/seed/medical-app/1200/800" 
              alt="PlumoPlus Dashboard" 
              className="w-full h-auto grayscale-[0.2] opacity-90"
              referrerPolicy="no-referrer"
            />
          </div>
        </motion.div>
      </section>

      {/* Features Grid */}
      <section className="bg-secondary/30 py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-3xl font-bold mb-4 font-heading">Everything you need to stay on track</h2>
            <p className="text-muted-foreground">Designed by medical professionals and patients, for patients.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((f, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -5 }}
                className="bg-card p-8 rounded-3xl shadow-sm border border-border/50"
              >
                <div className="mb-6">{f.icon}</div>
                <h3 className="text-xl font-bold mb-3 font-heading">{f.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{f.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-32 px-6 max-w-7xl mx-auto text-center">
        <div className="bg-primary rounded-[3rem] p-12 md:p-20 text-primary-foreground relative overflow-hidden">
          <div className="absolute top-0 right-0 p-10 opacity-10">
            <Heart className="h-64 w-64 fill-white" />
          </div>
          <h2 className="text-3xl md:text-5xl font-bold mb-8 relative z-10 font-heading">
            Ready to take control of your health?
          </h2>
          <p className="text-primary-foreground/80 mb-10 max-w-xl mx-auto text-lg relative z-10">
            Join thousands of patients using PlumoPlus to manage their recovery with confidence and clarity.
          </p>
          <Button onClick={signInWithGoogle} size="lg" className="bg-white text-primary hover:bg-white/90 h-14 px-10 text-lg rounded-2xl relative z-10">
            Join PlumoPlus Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-slate-100 text-center text-slate-400 text-sm">
        <p>© 2024 PlumoPlus. All rights reserved.</p>
        <div className="flex justify-center space-x-6 mt-4">
          <a href="#" className="hover:text-slate-600">Privacy Policy</a>
          <a href="#" className="hover:text-slate-600">Terms of Service</a>
          <a href="#" className="hover:text-slate-600">Contact Support</a>
        </div>
      </footer>
    </div>
  );
}
