import React, { useState, useEffect } from 'react';
import { UserProfile, Treatment, VitalSign, MedicalDocument } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Activity, Calendar, Phone, AlertCircle, CheckCircle2, Circle, Clock, Info, FileText, Sparkles, Heart } from 'lucide-react';
import { db, auth } from '../firebase';
import { collection, query, where, getDocs, limit, Timestamp, addDoc, orderBy } from 'firebase/firestore';
import { format, isSameDay } from 'date-fns';
import { motion } from 'motion/react';
import { toast } from 'sonner';

interface DashboardProps {
  profile: UserProfile | null;
}

export default function Dashboard({ profile }: DashboardProps) {
  const [todayTreatments, setTodayTreatments] = useState<Treatment[]>([]);
  const [recentDocs, setRecentDocs] = useState<MedicalDocument[]>([]);
  const [vitalsLoggedToday, setVitalsLoggedToday] = useState(false);
  const [adherenceStreak, setAdherenceStreak] = useState(0);
  const [loading, setLoading] = useState(true);
  const [quickSpo2, setQuickSpo2] = useState('');
  const [quickHeartRate, setQuickHeartRate] = useState('');
  const [isLogging, setIsLogging] = useState(false);

  const calculateStreak = (treatments: Treatment[]) => {
    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (let i = 0; i < 7; i++) {
      const checkDate = new Date(today);
      checkDate.setDate(checkDate.getDate() - i);
      
      const dayTreatments = treatments.filter(t => isSameDay(t.date.toDate(), checkDate));
      if (dayTreatments.length === 0) {
        if (i === 0) continue; // Skip today if no treatments scheduled yet
        break;
      }
      
      const allCompleted = dayTreatments.every(t => t.completed);
      if (allCompleted) {
        streak++;
      } else {
        if (i === 0) continue; // Don't break streak if today isn't finished yet
        break;
      }
    }
    setAdherenceStreak(streak);
  };

  const handleQuickLog = async () => {
    if (!auth.currentUser || (!quickSpo2 && !quickHeartRate)) return;
    setIsLogging(true);

    try {
      if (quickSpo2) {
        await addDoc(collection(db, 'vitals'), {
          uid: auth.currentUser.uid,
          type: 'spo2',
          value: parseFloat(quickSpo2),
          unit: '%',
          timestamp: Timestamp.now()
        });
      }
      if (quickHeartRate) {
        await addDoc(collection(db, 'vitals'), {
          uid: auth.currentUser.uid,
          type: 'heart_rate',
          value: parseFloat(quickHeartRate),
          unit: 'bpm',
          timestamp: Timestamp.now()
        });
      }
      setVitalsLoggedToday(true);
      setQuickSpo2('');
      setQuickHeartRate('');
      toast.success("Vitals logged successfully");
    } catch (error) {
      console.error("Quick log error:", error);
      toast.error("Failed to log vitals");
    } finally {
      setIsLogging(false);
    }
  };

  useEffect(() => {
    if (!auth.currentUser) return;

    const fetchData = async () => {
      try {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);

        // Fetch today's treatments
        const treatmentsQ = query(
          collection(db, 'treatments'),
          where('uid', '==', auth.currentUser.uid),
          where('date', '>=', Timestamp.fromDate(today)),
          where('date', '<', Timestamp.fromDate(tomorrow))
        );
        const treatmentsSnap = await getDocs(treatmentsQ);
        setTodayTreatments(treatmentsSnap.docs.map(d => ({ id: d.id, ...d.data() })) as Treatment[]);

        // Check if vitals logged today
        const vitalsQ = query(
          collection(db, 'vitals'),
          where('uid', '==', auth.currentUser.uid),
          where('timestamp', '>=', Timestamp.fromDate(today)),
          where('timestamp', '<', Timestamp.fromDate(tomorrow)),
          limit(1)
        );
        const vitalsSnap = await getDocs(vitalsQ);
        setVitalsLoggedToday(!vitalsSnap.empty);

        // Fetch recent documents
        const docsQ = query(
          collection(db, 'medical_documents'),
          where('uid', '==', auth.currentUser.uid),
          orderBy('date', 'desc'),
          limit(2)
        );
        const docsSnap = await getDocs(docsQ);
        setRecentDocs(docsSnap.docs.map(d => ({ id: d.id, ...d.data() })) as MedicalDocument[]);

        // Fetch last 7 days of treatments for streak
        const sevenDaysAgo = new Date(today);
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        const streakQ = query(
          collection(db, 'treatments'),
          where('uid', '==', auth.currentUser.uid),
          where('date', '>=', Timestamp.fromDate(sevenDaysAgo)),
          orderBy('date', 'desc')
        );
        const streakSnap = await getDocs(streakQ);
        calculateStreak(streakSnap.docs.map(d => ({ id: d.id, ...d.data() })) as Treatment[]);
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2 border-none shadow-sm">
          <CardHeader>
            <CardTitle>Welcome, {profile?.displayName}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap gap-2">
              {profile?.stage && (
                <div className="rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold text-primary">
                  {profile.stage.replace('_', ' ').toUpperCase()}
                </div>
              )}
              {profile?.diagnosisDate && (
                <div className="rounded-full bg-slate-100 dark:bg-slate-800 px-3 py-1 text-xs font-semibold text-slate-600 dark:text-slate-400">
                  Diagnosed: {profile.diagnosisDate}
                </div>
              )}
            </div>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              PlumoPlus is here to help you manage your journey. Use the tabs on the left to track your symptoms, view your treatment schedule, or ask our AI assistant any questions you might have.
            </p>
          </CardContent>
        </Card>

        {/* Emergency Contact Card */}
        <Card className="border-none shadow-sm bg-destructive/5 dark:bg-destructive/10 border-l-4 border-l-destructive">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-bold flex items-center text-destructive">
              <AlertCircle className="mr-2 h-4 w-4" />
              Emergency Contact
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {profile?.oncologistName ? (
              <>
                <div>
                  <p className="text-xs font-semibold text-destructive/80 uppercase tracking-wider">Oncologist</p>
                  <p className="text-sm font-medium">{profile.oncologistName}</p>
                </div>
                {profile.clinicPhone && (
                  <a 
                    href={`tel:${profile.clinicPhone}`}
                    className="flex items-center p-2 rounded-lg bg-white dark:bg-slate-900 shadow-sm text-destructive hover:bg-destructive/10 transition-colors"
                  >
                    <Phone className="mr-2 h-4 w-4" />
                    <span className="text-sm font-bold">{profile.clinicPhone}</span>
                  </a>
                )}
                {profile.emergencyInstructions && (
                  <div className="p-2 rounded bg-destructive/10">
                    <p className="text-[10px] text-destructive/80 leading-tight italic">
                      "{profile.emergencyInstructions}"
                    </p>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-2">
                <p className="text-xs text-destructive mb-2">No emergency info set.</p>
                <p className="text-[10px] text-destructive/70">Go to Settings to add your oncologist's contact info.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Adherence Streak */}
        <Card className="border-none shadow-sm bg-gradient-to-br from-primary to-primary/80 text-white overflow-hidden">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-bold flex items-center">
              <Sparkles className="mr-2 h-4 w-4" />
              Medication Adherence
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between">
              <div>
                <div className="text-3xl font-bold">{adherenceStreak} Day Streak</div>
                <p className="text-xs opacity-80 mt-1">Keep it up! Consistency is key to recovery.</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-white/20 flex items-center justify-center">
                <Heart className="h-6 w-6 fill-white" />
              </div>
            </div>
            <div className="mt-4 h-2 w-full bg-white/20 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${(adherenceStreak / 7) * 100}%` }}
                className="h-full bg-white"
              />
            </div>
            <div className="mt-2 flex justify-between text-[10px] font-bold opacity-60">
              <span>0 DAYS</span>
              <span>7 DAY GOAL</span>
            </div>
          </CardContent>
        </Card>

        {/* Today at a Glance */}
        <Card className="border-none shadow-sm overflow-hidden">
          <CardHeader className="bg-slate-50 dark:bg-slate-800/50">
            <CardTitle className="text-sm font-bold flex items-center">
              <Clock className="mr-2 h-4 w-4 text-blue-600" />
              Today at a Glance
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4 space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-xl bg-primary/5">
                <div className="flex items-center space-x-3">
                  <Calendar className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm font-medium">Treatments Today</p>
                    <p className="text-xs text-muted-foreground">{todayTreatments.length} items scheduled</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-primary">
                    {todayTreatments.filter(t => t.completed).length}/{todayTreatments.length}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-secondary/30">
                <div className="flex items-center space-x-3">
                  <Activity className="h-5 w-5 text-secondary-foreground" />
                  <div>
                    <p className="text-sm font-medium">Vitals Logged</p>
                    <p className="text-xs text-muted-foreground">{vitalsLoggedToday ? "Completed for today" : "Not yet recorded today"}</p>
                  </div>
                </div>
                <div>
                  {vitalsLoggedToday ? (
                    <CheckCircle2 className="h-5 w-5 text-secondary-foreground" />
                  ) : (
                    <Circle className="h-5 w-5 text-muted-foreground/30" />
                  )}
                </div>
              </div>
            </div>

            {todayTreatments.length > 0 && (
              <div className="space-y-2">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Next Up</p>
                {todayTreatments.filter(t => !t.completed).slice(0, 2).map(t => (
                  <div key={t.id} className="flex items-center justify-between text-sm">
                    <span className="text-slate-600 dark:text-slate-400">{t.title}</span>
                    <span className="text-slate-400">{format(t.date.toDate(), 'h:mm a')}</span>
                  </div>
                ))}
              </div>
            )}

            {recentDocs.length > 0 && (
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Recent Documents</p>
                {recentDocs.map(doc => (
                  <div key={doc.id} className="flex items-center justify-between text-sm">
                    <div className="flex items-center">
                      <FileText className="h-3 w-3 mr-2 text-blue-500" />
                      <span className="text-slate-600 dark:text-slate-400 truncate max-w-[150px]">{doc.title}</span>
                    </div>
                    <span className="text-[10px] text-slate-400">{doc.date}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Tips */}
        <div className="space-y-6">
          <Card className="border-none shadow-sm bg-primary text-primary-foreground">
            <CardHeader>
              <CardTitle className="text-sm font-bold flex items-center font-heading">
                <Info className="mr-2 h-4 w-4" />
                Quick Tip
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm leading-relaxed opacity-90">
                Staying hydrated is crucial during lung cancer treatment. Aim for 8-10 glasses of water daily to help manage fatigue and support your kidneys.
              </p>
              <div className="mt-4 pt-4 border-t border-white/20">
                <p className="text-[10px] uppercase tracking-widest opacity-60">Did you know?</p>
                <p className="text-xs mt-1">Light walking for just 10 minutes can significantly improve cancer-related fatigue.</p>
              </div>
            </CardContent>
          </Card>

          {/* Quick Log Vitals */}
          <Card className="border-none shadow-sm">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-bold">Quick Log Vitals</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">SpO2 (%)</label>
                  <input 
                    type="number" 
                    value={quickSpo2}
                    onChange={(e) => setQuickSpo2(e.target.value)}
                    placeholder="98"
                    className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Heart Rate</label>
                  <input 
                    type="number" 
                    value={quickHeartRate}
                    onChange={(e) => setQuickHeartRate(e.target.value)}
                    placeholder="72"
                    className="w-full bg-slate-50 dark:bg-slate-800 border-none rounded-lg p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
              </div>
              <button 
                onClick={handleQuickLog}
                disabled={isLogging || (!quickSpo2 && !quickHeartRate)}
                className="w-full py-2 bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 rounded-lg text-xs font-bold hover:opacity-90 transition-opacity disabled:opacity-50"
              >
                {isLogging ? "Logging..." : "Save Vitals"}
              </button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
