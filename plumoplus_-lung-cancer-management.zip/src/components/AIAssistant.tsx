import { useState, useRef, useEffect } from 'react';
import { getMedicalGuidance } from '../services/geminiService';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { MessageSquare, Send, Bot, User, Loader2, Info, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { db, auth } from '../firebase';
import { collection, query, where, orderBy, limit, getDocs, addDoc, onSnapshot, Timestamp, getDoc, doc } from 'firebase/firestore';
import { UserProfile, SymptomLog } from '../types';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: any[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error Details: ', JSON.stringify(errInfo, null, 2));
  // Don't throw, just log and set an error state if needed
}

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: any;
}

export default function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const quickPrompts = [
    "Explain my cancer stage",
    "How to manage fatigue?",
    "Diet tips for lung health",
    "What is immunotherapy?"
  ];

  useEffect(() => {
    if (!auth.currentUser) return;

    const path = 'chat_messages';
    const q = query(
      collection(db, path),
      where('uid', '==', auth.currentUser.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as Message[];
      // Sort messages by timestamp manually since we removed orderBy for index reasons
      msgs.sort((a, b) => {
        const t1 = a.timestamp?.toMillis?.() || a.timestamp?.getTime?.() || 0;
        const t2 = b.timestamp?.toMillis?.() || b.timestamp?.getTime?.() || 0;
        return t1 - t2;
      });

      if (msgs.length === 0) {
        setMessages([
          {
            id: 'welcome',
            text: "Hello! I'm your PlumoPlus Assistant. I can help explain medical terms, suggest ways to manage symptoms, or just provide a supportive ear. How can I help you today?",
            sender: 'ai',
            timestamp: new Date(),
          }
        ]);
      } else {
        setMessages(msgs);
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (textOverride?: string) => {
    const messageText = textOverride || input;
    if (!messageText.trim() || isLoading || !auth.currentUser) return;

    const userUid = auth.currentUser.uid;
    setIsLoading(true);
    if (!textOverride) setInput('');

    const path = 'chat_messages';
    try {
      // Save user message
      try {
        await addDoc(collection(db, path), {
          uid: userUid,
          text: messageText,
          sender: 'user',
          timestamp: Timestamp.now()
        });
      } catch (e) {
        handleFirestoreError(e, OperationType.WRITE, path);
      }

      // Gather context
      let contextPrompt = messageText;
      try {
        // Fetch profile
        const userDoc = await getDoc(doc(db, 'users', userUid));
        const profile = userDoc.exists() ? userDoc.data() as UserProfile : null;

        // Fetch recent symptoms
        const symptomDocs = await getDocs(query(
          collection(db, 'symptoms'), 
          where('uid', '==', userUid), 
          limit(10) // Fetch more and sort manually
        ));
        const symptoms = symptomDocs.docs
          .map(d => d.data() as SymptomLog)
          .sort((a, b) => b.timestamp.toMillis() - a.timestamp.toMillis())
          .slice(0, 3);

        if (profile || symptoms.length > 0) {
          contextPrompt = `
            USER CONTEXT:
            Role: ${profile?.role || 'Unknown'}
            Stage: ${profile?.stage || 'Unknown'}
            Recent Symptoms: ${symptoms.map(s => `${s.type} (Severity: ${s.severity}/10)`).join(', ') || 'None logged recently'}
            
            USER QUESTION:
            ${messageText}
          `;
        }
      } catch (e) {
        console.warn("Context fetch failed, continuing without context:", e);
      }

      const response = await getMedicalGuidance(contextPrompt);
      
      // Save AI message
      try {
        await addDoc(collection(db, path), {
          uid: userUid,
          text: response || "I'm sorry, I couldn't process that. Please try again.",
          sender: 'ai',
          timestamp: Timestamp.now()
        });
      } catch (e) {
        handleFirestoreError(e, OperationType.WRITE, path);
      }
    } catch (e) {
      console.error("Chat error:", e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col space-y-4 h-[calc(100vh-12rem)]">
      <Card className="flex-1 flex flex-col border-none shadow-sm overflow-hidden">
        <CardHeader className="border-b bg-slate-50/50">
          <CardTitle className="flex items-center text-sm font-medium">
            <Bot className="mr-2 h-4 w-4 text-blue-600" />
            PlumoPlus AI Support
          </CardTitle>
        </CardHeader>
        <CardContent className="flex-1 p-0 overflow-hidden flex flex-col">
          <ScrollArea className="flex-1 p-4" ref={scrollRef}>
            <div className="space-y-4">
              <AnimatePresence initial={false}>
                {messages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={cn(
                      "flex w-full",
                      msg.sender === 'user' ? "justify-end" : "justify-start"
                    )}
                  >
                    <div className={cn(
                      "flex max-w-[80%] items-start space-x-2 rounded-2xl p-3 text-sm",
                      msg.sender === 'user' 
                        ? "bg-blue-600 text-white rounded-tr-none" 
                        : "bg-slate-100 text-slate-900 rounded-tl-none"
                    )}
                    >
                      <div className="flex-1 whitespace-pre-wrap">{msg.text}</div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-slate-100 rounded-2xl rounded-tl-none p-3">
                    <Loader2 className="h-4 w-4 animate-spin text-slate-400" />
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="p-4 border-t bg-white dark:bg-slate-900">
            <div className="flex flex-wrap gap-2 mb-4">
              {quickPrompts.map((prompt) => (
                <button
                  key={prompt}
                  onClick={() => handleSend(prompt)}
                  disabled={isLoading}
                  className="text-[10px] px-2 py-1 rounded-full border border-slate-200 dark:border-slate-800 hover:bg-blue-50 dark:hover:bg-blue-900/30 hover:text-blue-600 dark:hover:text-blue-400 transition-colors text-slate-500 dark:text-slate-400"
                >
                  {prompt}
                </button>
              ))}
            </div>
            <div className="flex space-x-2">
              <Input 
                placeholder="Ask about symptoms, terms, or support..." 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                className="flex-1"
              />
              <Button onClick={() => handleSend()} disabled={isLoading || !input.trim()} className="bg-blue-600">
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <div className="mt-2 flex items-center text-[10px] text-slate-400">
              <Info className="mr-1 h-3 w-3" />
              AI responses are for guidance only. Consult your doctor for medical advice.
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
