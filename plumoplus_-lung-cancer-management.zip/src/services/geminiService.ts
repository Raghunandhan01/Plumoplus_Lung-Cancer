import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function getMedicalGuidance(prompt: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: "You are a supportive medical assistant specializing in lung cancer. Provide clear, empathetic explanations of medical terms, symptom management tips, and emotional support. Always advise the user to consult their primary oncologist for specific medical advice. Keep responses concise and scannable.",
      },
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm sorry, I'm having trouble connecting right now. Please try again later.";
  }
}
