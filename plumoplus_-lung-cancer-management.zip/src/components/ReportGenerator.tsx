import React, { useState } from 'react';
import { db, auth } from '../firebase';
import { collection, query, where, orderBy, getDocs, limit } from 'firebase/firestore';
import { SymptomLog, Treatment, VitalSign } from '../types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { toast } from 'sonner';
import { FileText, Download, Printer, Loader2, Calendar, Activity, ClipboardList } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { motion } from 'motion/react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, Label as RechartsLabel } from 'recharts';

export default function ReportGenerator() {
  const [loading, setLoading] = useState(false);
  const [reportData, setReportData] = useState<{
    symptoms: SymptomLog[];
    treatments: Treatment[];
    vitals: VitalSign[];
  } | null>(null);

  const generateReport = async (days: number) => {
    if (!auth.currentUser) return;
    setLoading(true);

    try {
      const startDate = subDays(new Date(), days);
      
      // Fetch Symptoms
      const symptomsQ = query(
        collection(db, 'symptoms'),
        where('uid', '==', auth.currentUser.uid),
        where('timestamp', '>=', startDate),
        orderBy('timestamp', 'desc')
      );
      const symptomsSnap = await getDocs(symptomsQ);
      const symptoms = symptomsSnap.docs.map(d => ({ id: d.id, ...d.data() })) as SymptomLog[];

      // Fetch Treatments
      const treatmentsQ = query(
        collection(db, 'treatments'),
        where('uid', '==', auth.currentUser.uid),
        where('date', '>=', startDate),
        orderBy('date', 'desc')
      );
      const treatmentsSnap = await getDocs(treatmentsQ);
      const treatments = treatmentsSnap.docs.map(d => ({ id: d.id, ...d.data() })) as Treatment[];

      // Fetch Vitals
      const vitalsQ = query(
        collection(db, 'vitals'),
        where('uid', '==', auth.currentUser.uid),
        where('timestamp', '>=', startDate),
        orderBy('timestamp', 'desc')
      );
      const vitalsSnap = await getDocs(vitalsQ);
      const vitals = vitalsSnap.docs.map(d => ({ id: d.id, ...d.data() })) as VitalSign[];

      setReportData({ symptoms, treatments, vitals });
      toast.success(`Report generated for last ${days} days`);
    } catch (error) {
      console.error("Error generating report:", error);
      toast.error("Failed to generate report");
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      <Card className="border-none shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center">
            <FileText className="mr-2 h-5 w-5 text-blue-600" />
            Doctor's Visit Report
          </CardTitle>
          <CardDescription>Generate a summary of your health data to share with your oncology team.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-3">
            <Button onClick={() => generateReport(7)} variant="outline" disabled={loading}>
              Last 7 Days
            </Button>
            <Button onClick={() => generateReport(14)} variant="outline" disabled={loading}>
              Last 14 Days
            </Button>
            <Button onClick={() => generateReport(30)} variant="outline" disabled={loading}>
              Last 30 Days
            </Button>
          </div>
        </CardContent>
      </Card>

      {loading && (
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
        </div>
      )}

      {reportData && !loading && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6 print:m-0 print:p-0"
        >
          <div className="flex justify-end space-x-2 print:hidden">
            <Button onClick={handlePrint} className="bg-slate-800">
              <Printer className="mr-2 h-4 w-4" /> Print Report
            </Button>
          </div>

          <div id="printable-report" className="bg-white p-8 rounded-xl border shadow-sm space-y-8 print:border-none print:shadow-none">
            <div className="flex justify-between items-start border-b pb-6">
              <div>
                <h2 className="text-2xl font-bold text-blue-600">PlumoPlus Health Summary</h2>
                <p className="text-slate-500">Generated on {format(new Date(), 'MMMM d, yyyy')}</p>
              </div>
              <div className="text-right text-sm text-slate-500">
                <p>Patient: {auth.currentUser?.displayName}</p>
                <p>Email: {auth.currentUser?.email}</p>
              </div>
            </div>

            <section className="space-y-4">
              <h3 className="text-lg font-bold flex items-center border-b pb-2">
                <Activity className="mr-2 h-5 w-5 text-red-500" /> Recent Symptoms
              </h3>
              <div className="grid gap-4">
                {reportData.symptoms.length > 0 ? reportData.symptoms.map(s => (
                  <div key={s.id} className="flex justify-between text-sm border-b border-slate-50 pb-2">
                    <div>
                      <span className="font-bold capitalize">{s.type.replace('_', ' ')}</span>
                      <p className="text-xs text-slate-500">{s.notes || 'No notes'}</p>
                    </div>
                    <div className="text-right">
                      <span className="font-medium">Severity: {s.severity}/10</span>
                      <p className="text-xs text-slate-500">{format(s.timestamp.toDate(), 'MMM d, h:mm a')}</p>
                    </div>
                  </div>
                )) : <p className="text-sm text-slate-400">No symptoms logged in this period.</p>}
              </div>
            </section>

            <section className="space-y-4">
              <h3 className="text-lg font-bold flex items-center border-b pb-2">
                <ClipboardList className="mr-2 h-5 w-5 text-blue-500" /> Treatment Adherence
              </h3>
              <div className="grid gap-4">
                {reportData.treatments.length > 0 ? reportData.treatments.map(t => (
                  <div key={t.id} className="flex justify-between text-sm border-b border-slate-50 pb-2">
                    <div>
                      <span className="font-bold">{t.title}</span>
                      <p className="text-xs text-slate-500 capitalize">{t.type}</p>
                    </div>
                    <div className="text-right">
                      <span className={t.completed ? "text-emerald-600 font-medium" : "text-amber-600 font-medium"}>
                        {t.completed ? "Completed" : "Pending"}
                      </span>
                      <p className="text-xs text-slate-500">{format(t.date.toDate(), 'MMM d, h:mm a')}</p>
                    </div>
                  </div>
                )) : <p className="text-sm text-slate-400">No treatments scheduled in this period.</p>}
              </div>
            </section>

            <section className="space-y-4">
              <h3 className="text-lg font-bold flex items-center border-b pb-2">
                <Activity className="mr-2 h-5 w-5 text-emerald-500" /> Vital Signs
              </h3>
              <div className="grid grid-cols-2 gap-4">
                {reportData.vitals.length > 0 ? reportData.vitals.map(v => (
                  <div key={v.id} className="text-sm border-b border-slate-50 pb-2">
                    <div className="flex justify-between">
                      <span className="font-bold capitalize">{v.type.replace('_', ' ')}</span>
                      <span>{v.value} {v.unit}</span>
                    </div>
                    <p className="text-xs text-slate-500">{format(v.timestamp.toDate(), 'MMM d, h:mm a')}</p>
                  </div>
                )) : <p className="text-sm text-slate-400">No vitals recorded in this period.</p>}
              </div>
            </section>

            <section className="space-y-4">
              <h3 className="text-lg font-bold flex items-center border-b pb-2">
                <History className="mr-2 h-5 w-5 text-purple-500" /> Symptom-Treatment Correlation
              </h3>
              <div className="h-[300px] w-full bg-slate-50/50 rounded-xl p-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={[...reportData.symptoms].reverse().map(s => ({
                    date: format(s.timestamp.toDate(), 'MMM d'),
                    severity: s.severity,
                    timestamp: s.timestamp.toDate().getTime()
                  }))}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis dataKey="date" fontSize={10} />
                    <YAxis domain={[0, 10]} fontSize={10} />
                    <Tooltip />
                    <Line type="monotone" dataKey="severity" stroke="#ef4444" strokeWidth={2} dot={{ r: 4 }} />
                    {reportData.treatments.map((t, idx) => (
                      <ReferenceLine 
                        key={t.id} 
                        x={format(t.date.toDate(), 'MMM d')} 
                        stroke="#3b82f6" 
                        strokeDasharray="3 3"
                      >
                        <RechartsLabel value="Tx" position="top" fontSize={8} fill="#3b82f6" />
                      </ReferenceLine>
                    ))}
                  </LineChart>
                </ResponsiveContainer>
                <p className="text-[10px] text-center text-slate-400 mt-2">
                  <span className="inline-block w-2 h-2 bg-red-500 rounded-full mr-1"></span> Symptom Severity 
                  <span className="inline-block w-2 h-2 bg-blue-500 rounded-full ml-3 mr-1"></span> Treatment Marker (Tx)
                </p>
              </div>
            </section>

            <div className="pt-8 text-center text-[10px] text-slate-400">
              <p>This report is generated by PlumoPlus and is intended for informational purposes only.</p>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}
