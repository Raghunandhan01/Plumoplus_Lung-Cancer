import React, { useState, useEffect } from 'react';
import { db, auth } from '../firebase';
import { collection, addDoc, query, where, onSnapshot, orderBy, Timestamp } from 'firebase/firestore';
import { SymptomLog, SymptomType } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Plus, History, TrendingUp, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../lib/utils';
import { toast } from 'sonner';

export default function SymptomTracker() {
  const [logs, setLogs] = useState<SymptomLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  
  // Form state
  const [type, setType] = useState<SymptomType>('cough');
  const [severity, setSeverity] = useState('5');
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (!auth.currentUser) return;

    const q = query(
      collection(db, 'symptoms'),
      where('uid', '==', auth.currentUser.uid),
      orderBy('timestamp', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const newLogs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as SymptomLog[];
      setLogs(newLogs);
      setLoading(false);
    }, (error) => {
      console.error("Symptoms listener error:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;

    try {
      await addDoc(collection(db, 'symptoms'), {
        uid: auth.currentUser.uid,
        type,
        severity: parseInt(severity),
        notes,
        timestamp: Timestamp.now()
      });
      setIsAdding(false);
      setNotes('');
      toast.success("Symptom logged successfully");
    } catch (error) {
      console.error("Error adding symptom:", error);
      toast.error("Failed to log symptom");
    }
  };

  const chartData = [...logs].reverse().map(log => ({
    date: format(log.timestamp.toDate(), 'MMM d'),
    severity: log.severity,
    type: log.type
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Symptom History</h3>
        <Button onClick={() => setIsAdding(!isAdding)} className="bg-blue-600">
          <Plus className="mr-2 h-4 w-4" />
          Log Symptom
        </Button>
      </div>

      {isAdding && (
        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle>Log New Symptom</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Symptom Type</Label>
                  <Select value={type} onValueChange={(v: SymptomType) => setType(v)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select symptom" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cough">Cough</SelectItem>
                      <SelectItem value="shortness_of_breath">Shortness of Breath</SelectItem>
                      <SelectItem value="chest_pain">Chest Pain</SelectItem>
                      <SelectItem value="fatigue">Fatigue</SelectItem>
                      <SelectItem value="weight_loss">Weight Loss</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Severity (1-10)</Label>
                  <Input 
                    type="number" 
                    min="1" 
                    max="10" 
                    value={severity} 
                    onChange={(e) => setSeverity(e.target.value)} 
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Notes</Label>
                <Textarea 
                  placeholder="How are you feeling? Any triggers?" 
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsAdding(false)}>Cancel</Button>
                <Button type="submit" className="bg-blue-600">Save Log</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2 border-none shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="mr-2 h-5 w-5 text-blue-600" />
              Severity Trend
            </CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            {loading ? (
              <div className="flex h-full items-center justify-center">
                <Loader2 className="h-6 w-6 animate-spin text-slate-300" />
              </div>
            ) : logs.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="date" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} domain={[0, 10]} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="severity" 
                    stroke="#2563eb" 
                    strokeWidth={3} 
                    dot={{ r: 4, fill: '#2563eb', strokeWidth: 2, stroke: '#fff' }}
                    activeDot={{ r: 6, strokeWidth: 0 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full flex-col items-center justify-center text-slate-400">
                <p>No logs yet. Start by adding your first symptom.</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center">
              <History className="mr-2 h-5 w-5 text-slate-400" />
              Recent Logs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {logs.slice(0, 5).map((log) => (
                <div key={log.id} className="flex items-start justify-between border-b border-slate-50 pb-3 last:border-0">
                  <div>
                    <p className="text-sm font-medium capitalize">{log.type.replace(/_/g, ' ')}</p>
                    <p className="text-xs text-slate-500">{format(log.timestamp.toDate(), 'MMM d, h:mm a')}</p>
                  </div>
                  <div className={cn(
                    "rounded-full px-2 py-1 text-xs font-bold",
                    log.severity > 7 ? "bg-red-50 text-red-600" : 
                    log.severity > 4 ? "bg-amber-50 text-amber-600" : 
                    "bg-green-50 text-green-600"
                  )}>
                    {log.severity}/10
                  </div>
                </div>
              ))}
              {logs.length === 0 && <p className="text-center text-sm text-slate-400">No recent logs</p>}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
